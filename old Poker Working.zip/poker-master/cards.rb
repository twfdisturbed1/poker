cards = {"2c" => '<img width="115" height="168" src="/images/card/2_of_clubs.png">',
       "3c" => '<img width="115" height="168" src="/images/card/3_of_clubs.png">'}
